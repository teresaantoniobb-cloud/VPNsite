require "sinatra"
require "sinatra/reloader" if development?
require "sequel"
require "bcrypt"
require "fileutils"
require "dotenv/load"

# ── CONFIGURAÇÃO ─────────────────────────────────────────────
set :app_file,     __FILE__
set :root,         File.dirname(__FILE__)
set :views,        File.join(settings.root, "views")
set :public_folder,File.join(settings.root, "public")
set :bind,         "0.0.0.0"
set :port,         ENV.fetch("PORT", 4567).to_i

SITE_NAME    = "VPN Free AO"
UPLOAD_DIR   = File.join(settings.root, "public", "uploads")
MAX_FILE_MB  = 50
ADMIN_USER   = ENV.fetch("ADMIN_USER", "admin")
ADMIN_PASS   = ENV.fetch("ADMIN_PASS", "admin123")

FileUtils.mkdir_p(UPLOAD_DIR)

# ── BASE DE DADOS ─────────────────────────────────────────────
DB = if ENV["DATABASE_URL"]
  Sequel.connect(ENV["DATABASE_URL"], max_connections: 10)
else
  Sequel.sqlite(File.join(settings.root, "data", "vpnfree.db"))
end
FileUtils.mkdir_p(File.join(settings.root, "data")) unless ENV["DATABASE_URL"]

# Criar tabelas se não existirem
DB.create_table?(:apps) do
  primary_key :id
  String  :slug,        null: false, unique: true
  String  :name,        null: false
  String  :icon,        default: "📱"
  String  :color,       default: "#00f0ff"
  String  :description, text: true
  Integer :sort_order,  default: 0
end

DB.create_table?(:vpn_files) do
  primary_key :id
  foreign_key :app_id, :apps, null: false, on_delete: :cascade
  String   :title,         null: false
  String   :description,   text: true
  String   :filename,      null: false
  String   :original_name, null: false
  Integer  :file_size,     default: 0
  String   :password,      default: ""
  String   :server,        default: ""
  Integer  :downloads,     default: 0
  Integer  :sort_order,    default: 0
  DateTime :created_at,    default: Sequel::CURRENT_TIMESTAMP
end

# Seed: inserir apps padrão
if DB[:apps].count == 0
  [
    { slug: "http-injector", name: "HTTP Injector",    icon: "💉", color: "#00e5ff", description: "Configurações para HTTP Injector. Importa o ficheiro .ehi directamente na app.", sort_order: 1 },
    { slug: "bd-net",        name: "BD Net",            icon: "🌐", color: "#00ff88", description: "Configurações para BD Net. Ficheiros prontos para importar na aplicação.", sort_order: 2 },
    { slug: "apna-tunnel",   name: "APNA Tunnel Lite",  icon: "⚡", color: "#ff6b35", description: "Configurações para APNA Tunnel Lite. Rápido e fácil de configurar.", sort_order: 3 },
    { slug: "maya-tun",      name: "Maya Tun Pro",      icon: "🌀", color: "#bd5fff", description: "Configurações para Maya Tun Pro. Alta velocidade e estabilidade.", sort_order: 4 },
  ].each { |a| DB[:apps].insert(a) }
end

# ── SESSÃO ────────────────────────────────────────────────────
use Rack::Session::Cookie,
  key:    "vpnfree.session",
  secret: ENV.fetch("SESSION_SECRET", "vpnfree_secret_change_me_#{rand(99999)}"),
  expire_after: 3600 * 8

# ── HELPERS ──────────────────────────────────────────────────
helpers do
  def h(str)
    Rack::Utils.escape_html(str.to_s)
  end

  def format_bytes(n)
    n = n.to_i
    return "#{n} B"  if n < 1024
    return "#{(n/1024.0).round} KB" if n < 1_048_576
    "#{(n/1_048_576.0).round(1)} MB"
  end

  def logged_in?
    session[:admin] == true
  end

  def require_admin!
    redirect "/admin/login" unless logged_in?
  end

  def apps_list
    DB[:apps].order(:sort_order, :name).all
  end

  def files_for_app(app_id, limit: 5)
    DB[:vpn_files].where(app_id: app_id).order(:sort_order, :created_at).limit(limit).all
  end

  def count_files(app_id)
    DB[:vpn_files].where(app_id: app_id).count
  end

  def allowed_ext?(filename)
    %w[ehi npx ovpn conf zip json txt vnn bin cfg].include?(
      File.extname(filename).delete(".").downcase
    )
  end
end

# ── ROTAS PÚBLICAS ────────────────────────────────────────────

get "/" do
  @apps = apps_list
  erb :index
end

get "/app/:slug" do
  @app   = DB[:apps].where(slug: params[:slug]).first
  halt 404, "App não encontrada" unless @app
  @files = files_for_app(@app[:id])
  erb :app
end

get "/download/:id" do
  file = DB[:vpn_files].where(id: params[:id].to_i).first
  halt 404, "Ficheiro não encontrado" unless file

  path = File.join(UPLOAD_DIR, file[:filename])
  halt 404, "Ficheiro não encontrado no servidor" unless File.exist?(path)

  DB[:vpn_files].where(id: file[:id]).update(downloads: Sequel[:downloads] + 1)

  send_file path,
    filename:    file[:original_name],
    type:        "application/octet-stream",
    disposition: "attachment"
end

# ── ADMIN ─────────────────────────────────────────────────────

get "/admin/login" do
  redirect "/admin" if logged_in?
  erb :admin_login, layout: false
end

post "/admin/login" do
  if params[:username] == ADMIN_USER && params[:password] == ADMIN_PASS
    session[:admin] = true
    redirect "/admin"
  else
    @error = "Credenciais inválidas."
    erb :admin_login, layout: false
  end
end

get "/admin/logout" do
  session.clear
  redirect "/admin/login"
end

get "/admin" do
  require_admin!
  @apps          = apps_list
  @total_files   = DB[:vpn_files].count
  @total_dl      = DB[:vpn_files].sum(:downloads).to_i
  erb :admin_dashboard, layout: :admin_layout
end

get "/admin/upload" do
  require_admin!
  @apps    = apps_list
  @pre_app = params[:app].to_i
  @msg     = session.delete(:msg)
  @err     = session.delete(:err)
  erb :admin_upload, layout: :admin_layout
end

post "/admin/upload" do
  require_admin!
  app_id  = params[:app_id].to_i
  title   = params[:title].to_s.strip
  desc    = params[:description].to_s.strip
  pass    = params[:password].to_s.strip
  server  = params[:server].to_s.strip
  sort    = params[:sort_order].to_i
  file    = params[:vpn_file]

  if app_id == 0 || title.empty? || file.nil?
    session[:err] = "Preenche todos os campos obrigatórios."
    redirect "/admin/upload"
  elsif count_files(app_id) >= 5
    session[:err] = "Esta app já tem 5 ficheiros. Elimina um primeiro."
    redirect "/admin/upload?app=#{app_id}"
  elsif !allowed_ext?(file[:filename])
    session[:err] = "Extensão não permitida: #{File.extname(file[:filename])}"
    redirect "/admin/upload"
  elsif file[:tempfile].size > MAX_FILE_MB * 1_048_576
    session[:err] = "Ficheiro demasiado grande (máx #{MAX_FILE_MB}MB)."
    redirect "/admin/upload"
  else
    ext      = File.extname(file[:filename]).downcase
    new_name = "vpn_#{Time.now.to_i}_#{rand(9999)}#{ext}"
    dest     = File.join(UPLOAD_DIR, new_name)
    FileUtils.cp(file[:tempfile].path, dest)

    DB[:vpn_files].insert(
      app_id: app_id, title: title, description: desc,
      filename: new_name, original_name: file[:filename],
      file_size: File.size(dest), password: pass,
      server: server, sort_order: sort,
      created_at: Time.now
    )
    session[:msg] = "Ficheiro carregado com sucesso!"
    redirect "/admin/upload?app=#{app_id}"
  end
end

get "/admin/files" do
  require_admin!
  @apps    = apps_list
  @sel_app = params[:app].to_i
  query    = DB[:vpn_files]
               .join(:apps, id: :app_id)
               .select(Sequel[:vpn_files].*, Sequel[:apps][:name].as(:app_name),
                       Sequel[:apps][:icon].as(:app_icon),
                       Sequel[:apps][:color].as(:app_color))
  query    = query.where(Sequel[:vpn_files][:app_id] => @sel_app) if @sel_app > 0
  @files   = query.order(Sequel[:vpn_files][:app_id], Sequel[:vpn_files][:sort_order]).all
  @msg     = session.delete(:msg)
  erb :admin_files, layout: :admin_layout
end

get "/admin/edit/:id" do
  require_admin!
  @file = DB[:vpn_files].where(id: params[:id].to_i).first
  halt 404 unless @file
  @apps = apps_list
  @msg  = session.delete(:msg)
  erb :admin_edit, layout: :admin_layout
end

post "/admin/edit/:id" do
  require_admin!
  id     = params[:id].to_i
  file   = DB[:vpn_files].where(id: id).first
  halt 404 unless file

  DB[:vpn_files].where(id: id).update(
    title:       params[:title].to_s.strip,
    description: params[:description].to_s.strip,
    app_id:      params[:app_id].to_i,
    password:    params[:password].to_s.strip,
    server:      params[:server].to_s.strip,
    sort_order:  params[:sort_order].to_i
  )

  new_file = params[:vpn_file]
  if new_file && !new_file[:filename].empty? && allowed_ext?(new_file[:filename])
    ext      = File.extname(new_file[:filename]).downcase
    new_name = "vpn_#{Time.now.to_i}_#{rand(9999)}#{ext}"
    dest     = File.join(UPLOAD_DIR, new_name)
    FileUtils.cp(new_file[:tempfile].path, dest)
    old_path = File.join(UPLOAD_DIR, file[:filename])
    File.delete(old_path) if File.exist?(old_path)
    DB[:vpn_files].where(id: id).update(
      filename: new_name, original_name: new_file[:filename],
      file_size: File.size(dest)
    )
  end

  session[:msg] = "Guardado com sucesso!"
  redirect "/admin/edit/#{id}"
end

get "/admin/delete/:id" do
  require_admin!
  file = DB[:vpn_files].where(id: params[:id].to_i).first
  if file
    path = File.join(UPLOAD_DIR, file[:filename])
    File.delete(path) if File.exist?(path)
    DB[:vpn_files].where(id: file[:id]).delete
  end
  redirect "/admin/files"
end
