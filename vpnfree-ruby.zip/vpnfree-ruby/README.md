# VPN Free AO — Ruby/Sinatra

## Estrutura
```
vpnfree-ruby/
├── app.rb               ← Aplicação principal (rotas + BD)
├── config.ru            ← Rack entry point (Render usa este)
├── Gemfile              ← Dependências Ruby
├── .env.example         ← Variáveis de ambiente de exemplo
├── .gitignore
├── data/                ← Base SQLite (desenvolvimento local)
├── public/uploads/      ← Ficheiros VPN carregados
└── views/
    ├── layout.erb           ← Layout público
    ├── index.erb            ← Página inicial
    ├── app.erb              ← Página de cada app VPN
    ├── admin_layout.erb     ← Layout do painel admin
    ├── admin_login.erb
    ├── admin_dashboard.erb
    ├── admin_upload.erb
    ├── admin_files.erb
    └── admin_edit.erb
```

---

## Testar localmente

```bash
gem install bundler
bundle install
cp .env.example .env   # edita o .env com as tuas credenciais
ruby app.rb
```

Acede em: http://localhost:4567

---

## Deploy no Render (passo a passo)

### 1. Cria conta no Render
- Vai a https://render.com e regista-te

### 2. Coloca o código no GitHub
```bash
git init
git add .
git commit -m "VPN Free AO"
# Cria um repositório no GitHub e faz push
git remote add origin https://github.com/SEU_USER/vpnfree-ruby.git
git push -u origin main
```

### 3. Cria uma base de dados PostgreSQL no Render
- Dashboard → New → PostgreSQL
- Nome: vpnfree-db
- Plano: Free
- Copia a **Internal Database URL**

### 4. Cria o Web Service no Render
- Dashboard → New → Web Service
- Conecta ao teu repositório GitHub
- Preenche:
  - **Name**: vpnfree
  - **Runtime**: Ruby
  - **Build Command**: `bundle install`
  - **Start Command**: `bundle exec puma -C config/puma.rb` ou `bundle exec ruby app.rb`
  - **Plan**: Free

### 5. Adiciona as variáveis de ambiente no Render
Em Environment → Add Environment Variable:

| Chave | Valor |
|-------|-------|
| `ADMIN_USER` | admin |
| `ADMIN_PASS` | a_tua_senha |
| `SESSION_SECRET` | string_aleatoria_longa |
| `DATABASE_URL` | (cola a URL do PostgreSQL) |

### 6. Deploy!
Clica em **Create Web Service** e aguarda o deploy.

---

## ⚠ Nota sobre ficheiros no Render

O Render (plano gratuito) tem **sistema de ficheiros efémero** — os ficheiros em `public/uploads/` são apagados quando o serviço reinicia.

**Solução recomendada**: usa um serviço de armazenamento externo como:
- **Cloudinary** (gratuito até 25GB)
- **Backblaze B2** (gratuito até 10GB)
- **Amazon S3**

Para uso simples e testes, o sistema actual funciona bem.
